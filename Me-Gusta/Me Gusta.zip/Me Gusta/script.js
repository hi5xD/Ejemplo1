function aumentarLikes1(){
    var content1 = document.getElementById("mg22")
    var like1 = parseInt(content1.innerHTML)
    content1.innerHTML = like1 + 1 + " like(s)"
}
function aumentarLikes2(){
    var content2 = document.getElementById("mg1")
    var like2 = parseInt(content2.innerHTML)
    content2.innerHTML = like2 + 1 + " like(s)"
}
function aumentarLikes3(){
    var content3 = document.getElementById("mg2")
    var like3 = parseInt(content3.innerHTML)
    content3.innerHTML = like3 + 1 + " like(s)"
}